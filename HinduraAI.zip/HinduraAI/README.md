# Hindura AI

Floating AI assistant for Android 8.0+ (API 26). Tap the logo on any screen to:
- 📷 read the screen and translate it (Kinyarwanda, English, French, Kiswahili, Kirundi and more)
- 🤟 get sign-language guidance (gloss + handshape steps)
- 🔊 hear the translation (Gemini voice, Android voice as fallback)
- ➤ ask questions about the page in any language

Powered by Google Gemini (default model: `gemini-2.5-flash`, free tier).

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and upload everything from this folder (keep the `.github` folder).
2. Open the **Actions** tab → wait for "Build Android APK" to finish (~5 min).
3. Download `HinduraAI.apk` from **Releases** (right side of the repo page) on your phone.
4. Install it (allow "install unknown apps" when asked).
5. Open Hindura AI → paste your Gemini API key → Start → allow *Display over other apps* and screen capture.

## Security
Your API key is typed into the app and stored only on your phone. Never commit it to GitHub.
