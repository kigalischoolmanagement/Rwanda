package com.hindura.ai

object Config {
    // Gemini API key lives here. Keep your GitHub repo PRIVATE.
    const val API_KEY = "AIzaSyBv_kj4ZcfZ46ovTJcXZBcUT9jj9LzQRew"
    const val MODEL = "gemini-2.5-flash"
}
