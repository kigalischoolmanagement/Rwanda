package com.hindura.ai

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.DisplayMetrics
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null

    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelShown = false
    private lateinit var resultView: TextView
    private lateinit var input: EditText
    private val chips = mutableListOf<TextView>()

    private val langs = listOf(
        "Kinyarwanda" to "rw", "English" to "en", "Français" to "fr", "Kiswahili" to "sw",
        "Kirundi" to "rn", "Español" to "es", "العربية" to "ar", "中文" to "zh",
        "हिन्दी" to "hi", "Português" to "pt", "Deutsch" to "de"
    )
    private var lang = "Kinyarwanda"
    private var lastB64: String? = null
    private var lastShot = 0L
    private var lastText = ""
    private var tts: TextToSpeech? = null
    private var track: AudioTrack? = null

    override fun onBind(i: Intent?): IBinder? = null

    // ---------- lifecycle ----------
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val ch = "hindura"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Hindura AI", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hindura AI is ready")
            .setContentText("Tap the floating logo to translate your screen")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = p
            val (w, h) = realSize()
            val r = newReader(w, h)
            reader = r
            vd = p.createVirtualDisplay("hindura", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            buildUi()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        try {
            val (w, h) = realSize()
            held?.close(); held = null
            val old = reader
            val nr = newReader(w, h)
            reader = nr
            vd?.resize(w, h, resources.displayMetrics.densityDpi)
            vd?.surface = nr.surface
            old?.close()
            panelLp?.let { it.width = (w * 0.94f).toInt(); if (panelShown) wm.updateViewLayout(panel, it) }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        try { if (panelShown) wm.removeView(panel) } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        held?.close(); vd?.release(); reader?.close()
        try { projection?.stop() } catch (_: Exception) {}
        tts?.shutdown(); track?.release(); io.shutdownNow()
        super.onDestroy()
    }

    // ---------- screen capture ----------
    private fun realSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) { held?.close(); held = img }
        }, main)
        return r
    }

    private fun encode(img: Image): String {
        val p = img.planes[0]
        val px = p.pixelStride
        val pad = p.rowStride - px * img.width
        val full = Bitmap.createBitmap(img.width + pad / px, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        var bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        val s = 1400f / maxOf(bmp.width, bmp.height)
        if (s < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun capture(done: (String?) -> Unit) {
        val b = bubble
        val pn = panel
        b?.visibility = View.INVISIBLE
        pn?.visibility = View.INVISIBLE
        main.postDelayed({
            var b64: String? = null
            try { held?.let { b64 = encode(it) } } catch (_: Exception) {}
            b?.visibility = View.VISIBLE
            pn?.visibility = View.VISIBLE
            if (b64 != null) { lastB64 = b64; lastShot = System.currentTimeMillis() }
            done(b64)
        }, 500)
    }

    // ---------- AI actions ----------
    private fun key() = getSharedPreferences("cfg", MODE_PRIVATE).getString("key", "") ?: ""
    private fun model() = getSharedPreferences("cfg", MODE_PRIVATE).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    private fun codeOf(name: String) = langs.firstOrNull { it.first == name }?.second ?: "en"

    private fun ready(): Boolean {
        if (key().isBlank()) { setResult("⚠️ Open the Hindura AI app and paste your Gemini API key."); return false }
        return true
    }

    private fun friendly(e: Exception): String = when {
        e is UnknownHostException -> "No internet connection."
        e is ApiError && (e.code == 400 || e.code == 403) && (e.message ?: "").contains("key", true) ->
            "Your API key is not valid. Check it in the Hindura AI app."
        e is ApiError && e.code == 429 -> "Free limit reached for now. Wait a minute and try again."
        else -> e.message ?: "Something went wrong."
    }

    private fun ai(prompt: String, img: String?, isAnswer: Boolean, after: ((String) -> Unit)? = null) {
        setResult("⏳ Thinking…")
        io.execute {
            try {
                val t = Gemini.generate(key(), model(), prompt, img)
                main.post { setResult(t); if (isAnswer) lastText = t; after?.invoke(t) }
            } catch (e: Exception) {
                main.post { setResult("⚠️ " + friendly(e)) }
            }
        }
    }

    private fun translate(thenSpeak: Boolean = false) {
        if (!ready()) return
        setResult("📷 Reading screen…")
        capture { b64 ->
            if (b64 == null) setResult("⚠️ Couldn't capture the screen. Please try again.")
            else ai("You are an expert translator. Read ALL the text visible in this screenshot (skip the phone status bar). " +
                    "Translate it into natural, correct $lang. Keep the original order and structure (titles, lists, buttons). " +
                    "If it is already in $lang, rewrite it simply and clearly. Output only the translation.",
                b64, true) { if (thenSpeak) speak() }
        }
    }

    private fun ask() {
        val q = input.text.toString().trim()
        if (q.isEmpty() || !ready()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        setFocusable(false)
        val go = { b64: String ->
            ai("Look carefully at this screenshot and answer the user's question about it. " +
                    "Reply in the same language the question is written in. Be clear and concise.\nQuestion: $q", b64, true)
        }
        val cached = lastB64
        if (cached != null && System.currentTimeMillis() - lastShot < 45000) go(cached)
        else {
            setResult("📷 Reading screen…")
            capture { b -> if (b == null) setResult("⚠️ Couldn't capture the screen. Please try again.") else go(b) }
        }
    }

    private fun sign() {
        if (!ready()) return
        fun prompt(txt: String?) =
            "Turn this content into sign-language guidance for a Deaf reader. Write in English using this format:\n" +
            "GLOSS: the message in sign-language word order, in CAPITAL words (short, no articles or 'to be').\n" +
            "Then a numbered list of signs: an emoji + SIGN NAME — handshape, location and movement in one short line.\n" +
            "Simplify long text to the 3–6 most important sentences. If a Rwandan Sign Language sign is not known, use international sign/ASL and say so.\n" +
            (if (txt != null) "Content:\n$txt" else "Content: the main text visible in the screenshot.")
        if (lastText.isNotBlank()) ai(prompt(lastText.take(1500)), null, false)
        else {
            setResult("📷 Reading screen…")
            capture { b -> if (b == null) setResult("⚠️ Couldn't capture the screen. Please try again.") else ai(prompt(null), b, false) }
        }
    }

    private fun speak() {
        if (lastText.isBlank()) { translate(true); return }
        if (!ready()) return
        val t = lastText.take(1800)
        setResult(lastText + "\n\n🔊 Preparing voice…")
        io.execute {
            try {
                val pcm = Gemini.tts(key(), t)
                main.post { setResult(lastText) }
                track?.release()
                val at = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
                at.write(pcm, 0, pcm.size)
                track = at
                at.play()
            } catch (e: Exception) {
                main.post { setResult(lastText); fallbackTts(t, codeOf(lang)) }
            }
        }
    }

    private fun fallbackTts(t: String, code: String) {
        val cur = tts
        if (cur != null) {
            cur.setLanguage(Locale.forLanguageTag(code)); cur.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h"); return
        }
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale.forLanguageTag(code))
                tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h")
            }
        }
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setResult(t: String) { resultView.text = t }

    private fun grad(c1: Int, c2: Int, r: Int = 14) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = dp(r).toFloat() }

    private fun btn(label: String, c1: String, c2: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(6), dp(12), dp(6), dp(12))
        background = grad(Color.parseColor(c1), Color.parseColor(c2))
        setOnClickListener { onClick() }
    }

    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    private fun vlp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun setFocusable(f: Boolean) {
        val lp = panelLp ?: return
        lp.flags = if (f) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (panelShown) wm.updateViewLayout(panel, lp)
    }

    private fun refreshChips() {
        chips.forEachIndexed { i, c ->
            val sel = langs[i].first == lang
            c.background = if (sel) grad(Color.parseColor("#00B8FF"), Color.parseColor("#7C4DFF"), 20)
            else grad(Color.parseColor("#1B2150"), Color.parseColor("#1B2150"), 20)
            c.setTextColor(if (sel) Color.WHITE else Color.parseColor("#AEB8FF"))
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val lp = panelLp ?: return
        if (panelShown) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            wm.removeView(p); panelShown = false
        } else {
            wm.addView(p, lp); panelShown = true
        }
    }

    private fun buildUi() {
        val sw = realSize().first
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        // floating bubble
        val img = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setBackgroundColor(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            elevation = dp(6).toFloat()
        }
        val bl = WindowManager.LayoutParams(dp(58), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(260)
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        img.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bl.x; sy = bl.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { bl.x = sx + dx; bl.y = sy + dy; wm.updateViewLayout(img, bl) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        bubble = img
        wm.addView(img, bl)

        // panel
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F00E1230")); cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.parseColor("#446D4CFF"))
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "✦ Hindura AI"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "—"; setTextColor(Color.parseColor("#AEB8FF")); textSize = 20f; setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { togglePanel() }
        })
        header.addView(TextView(this).apply {
            text = "⏻"; setTextColor(Color.parseColor("#FF6B9A")); textSize = 20f; setPadding(dp(10), 0, 0, 0)
            setOnClickListener { stopSelf() }
        })
        root.addView(header, vlp(0))

        // language chips
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        langs.forEach { (name, _) ->
            val c = TextView(this).apply {
                text = name; textSize = 13f; setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener { lang = name; refreshChips() }
            }
            chips.add(c)
            chipRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        }
        refreshChips()
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }, vlp(10))

        // actions
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(btn("📷 Translate", "#00B8FF", "#4C6DFF") { translate() }, wlp())
        actions.addView(btn("🤟 Sign", "#4C6DFF", "#9B4CFF") { sign() }, wlp())
        actions.addView(btn("🔊 Voice", "#9B4CFF", "#E02BFF") { speak() }, wlp())
        root.addView(actions, vlp(10))

        // result
        resultView = TextView(this).apply {
            text = "Tap 📷 Translate to read this screen, or type a question below."
            setTextColor(Color.parseColor("#E8ECFF")); textSize = 15f
            setTextIsSelectable(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(ScrollView(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#141A3D")); cornerRadius = dp(16).toFloat() }
            addView(resultView)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)).apply { topMargin = dp(10) })

        // ask row
        input = EditText(this).apply {
            hint = "Ask about this page… (any language)"
            setHintTextColor(Color.parseColor("#7C86C9")); setTextColor(Color.WHITE); textSize = 14f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#1B2150")); cornerRadius = dp(20).toFloat() }
            setOnEditorActionListener { _, _, _ -> ask(); true }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) {
                    setFocusable(true)
                    main.postDelayed({
                        requestFocus()
                        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(this, 0)
                    }, 150)
                }
                false
            }
        }
        val askRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        askRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        askRow.addView(btn("➤", "#00B8FF", "#E02BFF") { ask() },
            LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        root.addView(askRow, vlp(10))

        panel = root
        panelLp = WindowManager.LayoutParams((sw * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(16)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
    }
}
