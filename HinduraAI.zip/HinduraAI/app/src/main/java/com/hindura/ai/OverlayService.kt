package com.hindura.ai

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.DisplayMetrics
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.UnknownHostException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.CancellationException
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null

    private var bubble: ImageView? = null
    private var panel: PanelLayout? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var panelShown = false
    private lateinit var resultView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var wave: WaveView
    private lateinit var input: EditText
    private lateinit var btnT: TextView
    private lateinit var btnS: TextView
    private lateinit var btnV: TextView
    private lateinit var btnMic: TextView
    private val chips = mutableListOf<TextView>()
    private var showingHint = true

    private var lang = "Kinyarwanda"
    private var lastText = ""
    private var lastTextLang: String? = null

    // cached screenshot of the page (taken the moment the panel opens)
    private var shotB64: String? = null
    private var shotValid = false
    private var shotGen = 0

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var track: AudioTrack? = null
    private var speaking = false
    private var speakGen = 0
    private var micOn = false
    @Volatile private var micStop = false

    override fun onBind(i: Intent?): IBinder? = null

    private fun s(k: String) = Lang.s(lang, k)

    // ---------- lifecycle ----------
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lang = getSharedPreferences("cfg", MODE_PRIVATE).getString("lang", "Kinyarwanda") ?: "Kinyarwanda"
        val ch = "hindura"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "Hindura AI", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch)
            .setContentTitle("Hindura AI")
            .setContentText("●")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 29) {
            var t = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                t = t or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            startForeground(1, n, t)
        } else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            projection = p
            val (w, h) = realSize()
            val r = newReader(w, h)
            reader = r
            vd = p.createVirtualDisplay("hindura", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            buildUi()
            initTts()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        try {
            val (w, h) = realSize()
            held?.close(); held = null
            val old = reader
            val nr = newReader(w, h)
            reader = nr
            vd?.resize(w, h, resources.displayMetrics.densityDpi)
            vd?.surface = nr.surface
            old?.close()
            panelLp?.let { it.width = (w * 0.94f).toInt(); if (panelShown) wm.updateViewLayout(panel, it) }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        micStop = true; speakGen++
        try { if (panelShown) wm.removeView(panel) } catch (_: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        held?.close(); vd?.release(); reader?.close()
        try { projection?.stop() } catch (_: Exception) {}
        tts?.shutdown(); track?.release(); io.shutdownNow()
        super.onDestroy()
    }

    // ---------- screen capture ----------
    private fun realSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Pair(b.width(), b.height())
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            Pair(m.widthPixels, m.heightPixels)
        }

    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) { held?.close(); held = img }
        }, main)
        return r
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val px = p.pixelStride
        val pad = p.rowStride - px * img.width
        val full = Bitmap.createBitmap(img.width + pad / px, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        var bmp = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
        val sc = 1400f / maxOf(bmp.width, bmp.height)
        if (sc < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt(), (bmp.height * sc).toInt(), true)
        return bmp
    }

    private fun compress(bmp: Bitmap): String {
        val o = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 72, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    /** Called the instant the panel opens, so Translate has zero capture delay. */
    private fun snapshot() {
        val g = ++shotGen
        shotValid = false
        val img = held ?: return
        try {
            val bmp = toBitmap(img)
            io.execute {
                try {
                    val b = compress(bmp)
                    main.post { if (g == shotGen) { shotB64 = b; shotValid = true } }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun capture(done: (String?) -> Unit) {
        val b = bubble
        val pn = panel
        b?.visibility = View.INVISIBLE
        pn?.visibility = View.INVISIBLE
        main.postDelayed({
            var b64: String? = null
            try { held?.let { b64 = compress(toBitmap(it)) } } catch (_: Exception) {}
            b?.visibility = View.VISIBLE
            pn?.visibility = View.VISIBLE
            shotGen++
            shotB64 = b64
            shotValid = b64 != null
            done(b64)
        }, 300)
    }

    private fun ensureShot(cb: (String?) -> Unit) {
        val cached = shotB64
        if (shotValid && cached != null) cb(cached) else capture(cb)
    }

    // ---------- AI ----------
    private fun friendly(e: Exception): String = when {
        e is UnknownHostException -> "No internet connection."
        e is ApiError && (e.code == 400 || e.code == 403) && (e.message ?: "").contains("key", true) ->
            "API key is not valid."
        e is ApiError && e.code == 429 -> "Free limit reached for now. Try again in a minute."
        else -> e.message ?: "Something went wrong."
    }

    private fun ai(prompt: String, img: String?, audio: String?, textLang: String?, isAnswer: Boolean,
                   after: (() -> Unit)? = null) {
        setResult("⏳")
        io.execute {
            try {
                val t = Gemini.generateStream(Config.API_KEY, Config.MODEL, prompt, img, audio) { part ->
                    main.post { setResult(part) }
                }
                main.post {
                    setResult(t)
                    if (isAnswer) { lastText = t; lastTextLang = textLang }
                    after?.invoke()
                }
            } catch (e: Exception) {
                main.post { setResult("⚠️ " + friendly(e)) }
            }
        }
    }

    private fun translate(thenSpeak: Boolean = false) {
        stopSpeaking()
        setResult("⏳")
        ensureShot { b ->
            if (b == null) setResult(s("cant"))
            else ai("Translate ALL text visible in this screenshot (ignore the status bar) into natural, correct $lang. " +
                    "Keep the order and structure. If it is already $lang, rewrite it simply. Output only the translation.",
                b, null, Lang.code(lang), true) { if (thenSpeak) startSpeak() }
        }
    }

    private fun askTyped() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        input.setText("")
        hideKeyboard()
        stopSpeaking()
        setResult("⏳")
        ensureShot { b ->
            if (b == null) setResult(s("cant"))
            else ai("Look at this screenshot and answer the user's question about it. " +
                    "Reply in the same language as the question. Be clear and concise.\nQuestion: $q",
                b, null, null, true)
        }
    }

    private fun sign() {
        stopSpeaking()
        setResult("⏳")
        val p = "Turn this into sign-language guidance for a Deaf reader. Write in English:\n" +
                "GLOSS: the message in sign-language word order, in CAPITAL words (short, no articles).\n" +
                "Then a numbered list: emoji + SIGN — handshape, location and movement in one short line.\n" +
                "Simplify long text to the 3–6 key sentences. If no Rwandan Sign Language sign is known, use international sign/ASL and say so.\n"
        if (lastText.isNotBlank()) ai(p + "Content:\n" + lastText.take(1500), null, null, null, false)
        else ensureShot { b ->
            if (b == null) setResult(s("cant")) else ai(p + "Content: the main text visible in the screenshot.", b, null, null, false)
        }
    }

    // ---------- voice question (mic) ----------
    private fun mic() {
        if (micOn) { micStop = true; return }
        stopSpeaking()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setResult("🎤 ✖"); return
        }
        micOn = true; micStop = false
        showWave(true)
        io.execute {
            val pcm = try { record() } catch (e: Exception) { null }
            main.post {
                micOn = false
                showWave(false)
                if (pcm != null) {
                    val audio = Base64.encodeToString(wav(pcm), Base64.NO_WRAP)
                    setResult("⏳")
                    ensureShot { b ->
                        if (b == null) setResult(s("cant"))
                        else ai("The user is asking a spoken question (audio) about this screenshot. " +
                                "Listen and answer it. Reply in the language the user spoke. Be clear and concise.",
                            b, audio, null, true)
                    }
                }
            }
        }
    }

    private fun record(): ByteArray? {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2)
        if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); return null }
        val out = ByteArrayOutputStream()
        val buf = ShortArray(1024)
        var heard = false
        var quiet = 0
        val t0 = SystemClock.uptimeMillis()
        ar.startRecording()
        try {
            while (!micStop) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) break
                var sum = 0.0
                for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                val rms = sqrt(sum / n)
                val lv = minOf(1f, (rms / 6000.0).toFloat())
                main.post { wave.level = lv }
                val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until n) bb.putShort(buf[i])
                out.write(bb.array())
                if (rms > 1100) { heard = true; quiet = 0 }
                else if (heard) { quiet += n; if (quiet > rate * 1.3) break }
                val el = SystemClock.uptimeMillis() - t0
                if (!heard && el > 7000) return null
                if (el > 20000) break
            }
        } finally {
            try { ar.stop() } catch (_: Exception) {}
            ar.release()
        }
        return if (heard) out.toByteArray() else null
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1)
        bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    // ---------- read aloud (waves only) ----------
    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { endSpeak() } }
                    override fun onError(id: String?) { main.post { endSpeak() } }
                })
            }
        }
    }

    private fun speak() {
        if (speaking) { stopSpeaking(); return }
        if (lastText.isBlank()) { translate(true); return }
        startSpeak()
    }

    private fun startSpeak() {
        val t = lastText.take(1500)
        val code = lastTextLang
        try { tts?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        val gen = ++speakGen
        speaking = true
        showWave(true)
        wave.level = 0.55f
        val eng = tts
        if (code != null && ttsReady && eng != null &&
            eng.isLanguageAvailable(Locale.forLanguageTag(code)) >= TextToSpeech.LANG_AVAILABLE) {
            eng.setLanguage(Locale.forLanguageTag(code))
            eng.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h")
            return
        }
        io.execute {
            try {
                playGemini(t, gen)
            } catch (e: Exception) {
                main.post {
                    if (gen == speakGen) {
                        val e2 = tts
                        if (ttsReady && e2 != null) {
                            e2.setLanguage(Locale.forLanguageTag(code ?: Lang.code(lang)))
                            e2.speak(t, TextToSpeech.QUEUE_FLUSH, null, "h")
                        } else endSpeak()
                    }
                }
            }
        }
    }

    private fun rms(b: ByteArray, off: Int, len: Int): Float {
        var sum = 0.0; var i = off; var n = 0
        while (i + 1 < off + len) {
            val v = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += v.toDouble() * v; i += 2; n++
        }
        return if (n == 0) 0f else minOf(1f, (sqrt(sum / n) / 7000.0).toFloat())
    }

    private fun playGemini(text: String, gen: Int) {
        val rate = 24000
        val minb = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(minb, rate))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        track?.release(); track = at
        at.play()
        var frames = 0L
        try {
            Gemini.ttsStream(Config.API_KEY, text) { pcm ->
                var off = 0
                while (off < pcm.size) {
                    if (gen != speakGen) throw CancellationException()
                    val len = minOf(4800, pcm.size - off)
                    at.write(pcm, off, len)
                    val lv = rms(pcm, off, len)
                    main.post { if (gen == speakGen) wave.level = lv }
                    off += len; frames += len / 2
                }
            }
            val deadline = SystemClock.uptimeMillis() + frames * 1000 / rate + 3000
            while (gen == speakGen && at.playbackHeadPosition < frames && SystemClock.uptimeMillis() < deadline)
                Thread.sleep(40)
        } catch (e: CancellationException) { return }
        main.post { if (gen == speakGen) endSpeak() }
    }

    private fun endSpeak() { speaking = false; if (!micOn) showWave(false) }

    private fun stopSpeaking() {
        speakGen++
        speaking = false
        try { tts?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        if (!micOn) showWave(false)
    }

    private fun showWave(on: Boolean) {
        if (!::wave.isInitialized) return
        wave.visibility = if (on) View.VISIBLE else View.GONE
        scroll.visibility = if (on) View.INVISIBLE else View.VISIBLE
        if (on) wave.start() else wave.stop()
        btnMic.text = if (micOn) "⏹" else "🎤"
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setResult(t: String) { showingHint = false; resultView.text = t }
    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun grad(c1: Int, c2: Int, r: Int = 14) =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply { cornerRadius = dp(r).toFloat() }

    private fun btn(label: String, c1: String, c2: String, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(6), dp(12), dp(6), dp(12))
        background = grad(Color.parseColor(c1), Color.parseColor(c2))
        setOnClickListener { onClick() }
    }

    private fun wlp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), 0, dp(3), 0) }
    private fun vlp(top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top) }

    private fun refreshChips() {
        chips.forEachIndexed { i, c ->
            val sel = Lang.all[i].first == lang
            c.background = if (sel) grad(Color.parseColor("#00B8FF"), Color.parseColor("#7C4DFF"), 20)
            else grad(Color.parseColor("#1B2150"), Color.parseColor("#1B2150"), 20)
            c.setTextColor(if (sel) Color.WHITE else Color.parseColor("#AEB8FF"))
        }
    }

    private fun applyStrings() {
        btnT.text = s("translate"); btnS.text = s("sign"); btnV.text = s("voice")
        input.hint = s("hint")
        if (showingHint) resultView.text = s("tapHint")
    }

    private fun openPanel() {
        snapshot()
        wm.addView(panel, panelLp)
        panelShown = true
    }

    private fun closePanel() {
        stopSpeaking(); micStop = true
        hideKeyboard()
        try { wm.removeView(panel) } catch (_: Exception) {}
        panelShown = false
    }

    private fun togglePanel() { if (panelShown) closePanel() else openPanel() }

    private fun buildUi() {
        val sw = realSize().first
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

        // floating bubble
        val img = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            setBackgroundColor(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            elevation = dp(6).toFloat()
        }
        val bl = WindowManager.LayoutParams(dp(58), dp(58), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(260)
        }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        img.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bl.x; sy = bl.y; tx = e.rawX; ty = e.rawY; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { bl.x = sx + dx; bl.y = sy + dy; wm.updateViewLayout(img, bl) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        bubble = img
        wm.addView(img, bl)

        // panel
        val root = PanelLayout(this) { closePanel() }.apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F00E1230")); cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.parseColor("#446D4CFF"))
            }
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_OUTSIDE) { shotGen++; shotValid = false }
                false
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "✦ Hindura AI"; setTextColor(Color.WHITE); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "—"; setTextColor(Color.parseColor("#AEB8FF")); textSize = 20f; setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { closePanel() }
        })
        header.addView(TextView(this).apply {
            text = "⏻"; setTextColor(Color.parseColor("#FF6B9A")); textSize = 20f; setPadding(dp(10), 0, 0, 0)
            setOnClickListener { stopSelf() }
        })
        root.addView(header, vlp(0))

        // language chips
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Lang.all.forEach { (name, _) ->
            val c = TextView(this).apply {
                text = name; textSize = 13f; setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener {
                    lang = name
                    getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("lang", name).apply()
                    refreshChips(); applyStrings()
                }
            }
            chips.add(c)
            chipRow.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(6) })
        }
        refreshChips()
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }, vlp(10))

        // actions
        btnT = btn(s("translate"), "#00B8FF", "#4C6DFF") { translate() }
        btnS = btn(s("sign"), "#4C6DFF", "#9B4CFF") { sign() }
        btnV = btn(s("voice"), "#9B4CFF", "#E02BFF") { speak() }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(btnT, wlp()); actions.addView(btnS, wlp()); actions.addView(btnV, wlp())
        root.addView(actions, vlp(10))

        // result container (text, or waves while listening / reading)
        resultView = TextView(this).apply {
            text = s("tapHint")
            setTextColor(Color.parseColor("#E8ECFF")); textSize = 15f
            setTextIsSelectable(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        scroll = ScrollView(this).apply { addView(resultView) }
        wave = WaveView(this).apply {
            visibility = View.GONE
            setOnClickListener { if (micOn) micStop = true else stopSpeaking() }
        }
        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#141A3D")); cornerRadius = dp(16).toFloat() }
            addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
            addView(wave, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        root.addView(box, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(10) })

        // ask row: type or speak
        input = EditText(this).apply {
            hint = s("hint")
            setHintTextColor(Color.parseColor("#7C86C9")); setTextColor(Color.WHITE); textSize = 14f
            setSingleLine(true); imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply { setColor(Color.parseColor("#1B2150")); cornerRadius = dp(20).toFloat() }
            setOnEditorActionListener { _, _, _ -> askTyped(); true }
        }
        btnMic = btn("🎤", "#00B8FF", "#7C4DFF") { mic() }
        val askRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        askRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        askRow.addView(btnMic, LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(8) })
        askRow.addView(btn("➤", "#7C4DFF", "#E02BFF") { askTyped() },
            LinearLayout.LayoutParams(dp(50), ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(6) })
        root.addView(askRow, vlp(10))

        panel = root
        // focusable window so typing always works; touches outside still reach the app below
        panelLp = WindowManager.LayoutParams((sw * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(16)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                    WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
    }
}
