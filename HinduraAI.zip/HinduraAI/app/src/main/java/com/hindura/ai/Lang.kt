package com.hindura.ai

object Lang {
    val all = listOf(
        "Kinyarwanda" to "rw", "English" to "en", "Français" to "fr", "Kiswahili" to "sw",
        "Kirundi" to "rn", "Español" to "es", "العربية" to "ar", "中文" to "zh",
        "हिन्दी" to "hi", "Português" to "pt", "Deutsch" to "de"
    )

    fun code(name: String) = all.firstOrNull { it.first == name }?.second ?: "en"

    private val en = mapOf(
        "choose" to "Choose your language",
        "tagline" to "Translate anything on your screen.",
        "start" to "▶  Start assistant",
        "change" to "Change language",
        "translate" to "📷 Translate",
        "sign" to "🤟 Sign",
        "voice" to "🔊 Read",
        "hint" to "Ask about this page…",
        "tapHint" to "Tap 📷 Translate to read this screen, or ask a question below.",
        "cant" to "⚠️ Couldn't capture the screen. Try again."
    )
    private val rw = mapOf(
        "choose" to "Hitamo ururimi ushaka gukoresha",
        "tagline" to "Hindura ibiri kuri ecran yawe mu rurimi ushaka.",
        "start" to "▶  Tangira",
        "change" to "Hindura ururimi",
        "translate" to "📷 Hindura",
        "sign" to "🤟 Amarenga",
        "voice" to "🔊 Soma",
        "hint" to "Baza ikibazo kuri uru rupapuro…",
        "tapHint" to "Kanda 📷 Hindura kugira ngo usome uru rupapuro, cyangwa wandike ikibazo hepfo.",
        "cant" to "⚠️ Ntibishobotse gufata ecran. Ongera ugerageze."
    )
    private val fr = mapOf(
        "choose" to "Choisissez votre langue",
        "tagline" to "Traduisez tout ce qui est sur votre écran.",
        "start" to "▶  Démarrer",
        "change" to "Changer de langue",
        "translate" to "📷 Traduire",
        "sign" to "🤟 Signes",
        "voice" to "🔊 Lire",
        "hint" to "Posez une question sur cette page…",
        "tapHint" to "Touchez 📷 Traduire pour lire cet écran, ou posez une question ci-dessous.",
        "cant" to "⚠️ Capture d'écran impossible. Réessayez."
    )
    private val sw = mapOf(
        "choose" to "Chagua lugha yako",
        "tagline" to "Tafsiri kila kitu kwenye skrini yako.",
        "start" to "▶  Anza",
        "change" to "Badilisha lugha",
        "translate" to "📷 Tafsiri",
        "sign" to "🤟 Ishara",
        "voice" to "🔊 Soma",
        "hint" to "Uliza swali kuhusu ukurasa huu…",
        "tapHint" to "Gusa 📷 Tafsiri kusoma skrini hii, au uliza swali hapa chini.",
        "cant" to "⚠️ Imeshindwa kunasa skrini. Jaribu tena."
    )
    private val tables = mapOf("Kinyarwanda" to rw, "Français" to fr, "Kiswahili" to sw)

    fun s(lang: String, k: String): String = tables[lang]?.get(k) ?: en[k] ?: k
}
