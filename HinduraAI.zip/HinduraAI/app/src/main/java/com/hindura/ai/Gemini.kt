package com.hindura.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ApiError(msg: String, val code: Int) : Exception(msg)

object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    const val TTS_MODEL = "gemini-2.5-flash-preview-tts"

    private fun post(key: String, model: String, body: JSONObject): JSONObject {
        for (attempt in 0..1) {
            val c = URL("$BASE$model:generateContent").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 90000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream.bufferedReader().use { it.readText() }
            if (code in 200..299) return JSONObject(txt)
            if ((code == 503 || code == 429) && attempt == 0) { Thread.sleep(2000); continue }
            val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(200) }
            throw ApiError(msg, code)
        }
        throw Exception("Request failed")
    }

    fun generate(key: String, model: String, prompt: String, imgB64: String?): String {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (imgB64 != null) {
            parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", imgB64)))
        }
        val gen = JSONObject().put("temperature", 0.3)
        if (model.contains("2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", gen)
        val res = post(key, model, body)
        val cands = res.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw Exception("The AI returned no answer (content may have been blocked).")
        val ps = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw Exception("Empty answer from AI.")
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    /** Returns raw 16-bit PCM, 24 kHz, mono. */
    fun tts(key: String, text: String): ByteArray {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Kore")))))
        val res = post(key, TTS_MODEL, body)
        val data = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        return Base64.decode(data, Base64.DEFAULT)
    }
}
