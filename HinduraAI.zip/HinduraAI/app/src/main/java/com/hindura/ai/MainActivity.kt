package com.hindura.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private val bg = Color.parseColor("#0A0D24")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lang() = prefs.getString("lang", "Kinyarwanda") ?: "Kinyarwanda"
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        if (prefs.getString("lang", null) == null) showPicker() else showHome()
    }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(24), dp(40), dp(24), dp(32))
    }

    private fun show(col: LinearLayout) {
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(col) })
    }

    private fun logo(size: Int) = ImageView(this).apply { setImageResource(R.drawable.logo) }

    private fun title(t: String, size: Float, color: String = "#FFFFFF") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color)); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(12), 0, dp(6))
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#161B45")); cornerRadius = dp(16).toFloat()
            setStroke(dp(1), Color.parseColor("#446D4CFF"))
        }
        setOnClickListener { onClick() }
    }

    // ---- first screen: choose language ----
    private fun showPicker() {
        val col = column()
        col.addView(logo(90), LinearLayout.LayoutParams(dp(90), dp(90)))
        col.addView(title("Choose your language\nHitamo ururimi", 22f), full())
        Lang.all.forEach { (name, _) ->
            col.addView(pill(name) {
                prefs.edit().putString("lang", name).apply()
                showHome()
            }, full().apply { topMargin = dp(10) })
        }
        show(col)
    }

    // ---- home ----
    private fun showHome() {
        val l = lang()
        val col = column()
        col.addView(logo(120), LinearLayout.LayoutParams(dp(120), dp(120)))
        col.addView(title("Hindura AI", 30f), full())
        col.addView(TextView(this).apply {
            text = Lang.s(l, "tagline"); textSize = 15f
            setTextColor(Color.parseColor("#9AA6FF")); gravity = Gravity.CENTER
        }, full())
        col.addView(pill("🌐  $l  ·  ${Lang.s(l, "change")}") { showPicker() }, full().apply { topMargin = dp(28) })
        col.addView(TextView(this).apply {
            text = Lang.s(l, "start"); textSize = 18f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(16), dp(18), dp(16), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#00B8FF"), Color.parseColor("#6D4CFF"), Color.parseColor("#E02BFF")))
                .apply { cornerRadius = dp(18).toFloat() }
            setOnClickListener { start() }
        }, full().apply { topMargin = dp(16) })
        show(col)
    }

    // ---- permissions + start ----
    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Enable “Display over other apps” for Hindura AI, then come back and tap Start")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO)
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        askCapture()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 100 && res == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (rc == 100) {
            toast("Screen capture permission is needed to read your screen")
        }
    }
}
