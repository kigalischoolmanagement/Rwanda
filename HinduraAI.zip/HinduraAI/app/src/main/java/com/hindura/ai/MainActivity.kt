package com.hindura.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(hint: String) = EditText(this).apply {
        this.hint = hint
        setHintTextColor(Color.parseColor("#7C86C9"))
        setTextColor(Color.WHITE)
        textSize = 15f
        setSingleLine(true)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.parseColor("#161B45")); cornerRadius = dp(14).toFloat() }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.parseColor("#AEB8FF")); textSize = 13f
        setPadding(0, dp(16), 0, dp(6))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0A0D24")
        window.navigationBarColor = Color.parseColor("#0A0D24")
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(32))
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(110), dp(110)))
        col.addView(TextView(this).apply {
            text = "Hindura AI"; textSize = 30f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4))
        })
        col.addView(TextView(this).apply {
            text = "Translate anything on your screen.\nKinyarwanda • English • Sign • Voice"
            textSize = 14f; setTextColor(Color.parseColor("#9AA6FF")); gravity = Gravity.CENTER
        })

        col.addView(label("Gemini API key"), full())
        keyBox = box("Paste your key (AIza…)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(sp.getString("key", ""))
        }
        col.addView(keyBox, full())
        col.addView(TextView(this).apply {
            text = "Get a free key → aistudio.google.com/apikey"
            textSize = 12f; setTextColor(Color.parseColor("#00C8FF")); setPadding(0, dp(6), 0, 0)
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey"))) }
        }, full())

        col.addView(label("AI model (free tier)"), full())
        modelBox = box("gemini-2.5-flash").apply { setText(sp.getString("model", "gemini-2.5-flash")) }
        col.addView(modelBox, full())

        col.addView(TextView(this).apply {
            text = "▶  Start floating assistant"; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#00B8FF"), Color.parseColor("#6D4CFF"), Color.parseColor("#E02BFF")))
                .apply { cornerRadius = dp(18).toFloat() }
            setOnClickListener { start() }
        }, full().apply { topMargin = dp(28) })

        col.addView(TextView(this).apply {
            text = "1. Allow “Display over other apps”\n2. Allow screen capture\n3. Tap the floating logo on any screen\n\n📷 Translate  •  🤟 Sign  •  🔊 Voice\nAsk questions about the page in any language."
            textSize = 13f; setTextColor(Color.parseColor("#8C97E6")); setPadding(0, dp(24), 0, 0)
        }, full())

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0D24")); addView(col)
        })
    }

    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun start() {
        val k = keyBox.text.toString().trim()
        if (k.isEmpty()) { toast("Paste your Gemini API key first"); return }
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("key", k)
            .putString("model", modelBox.text.toString().trim().ifEmpty { "gemini-2.5-flash" })
            .apply()
        if (!Settings.canDrawOverlays(this)) {
            toast("Enable “Display over other apps” for Hindura AI, then come back and tap Start")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            return
        }
        askCapture()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == 100 && res == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            toast("Floating button is ready ✦")
            moveTaskToBack(true)
        } else if (rc == 100) {
            toast("Screen capture permission is needed to read your screen")
        }
    }
}
